# -*- coding: utf-8 -*-
"""
Created on 10/1/17
Author: Jihoon Kim
"""

api_url = "https://api.bithumb.com"
