from trader.trader import *

trader = Trader()
trader.run_trading()
