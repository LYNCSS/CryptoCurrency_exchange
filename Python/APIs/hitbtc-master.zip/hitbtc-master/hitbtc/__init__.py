"""HitBTC WSS API V2.0 Client."""

from hitbtc.client import HitBTC

